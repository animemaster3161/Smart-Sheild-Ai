const SERVER_URL = "http://localhost:8080";
let failedAttempts = 0;

// ==========================================
// 🎨 CHART DRAWING FUNCTIONS
// ==========================================

function drawThreatMeter(total, blocked) {
    let canvas = document.getElementById('gaugeCanvas');
    if (!canvas) return;
    let ctx = canvas.getContext('2d');
    
    let threatPct = total > 0 ? Math.round((blocked / total) * 100) : 0;
    
    let w = canvas.width, h = canvas.height;
    let cx = w / 2, cy = h - 10, r = 70;

    ctx.clearRect(0, 0, w, h);

    // Background Gray Arc
    ctx.beginPath();
    ctx.arc(cx, cy, r, Math.PI, 0);
    ctx.lineWidth = 12;
    ctx.strokeStyle = 'rgba(255,255,255,0.05)';
    ctx.stroke();

    // Decide Color based on Threat Level
    let color = '#00d97e'; // Green
    if (threatPct > 20) color = '#f59e0b'; // Amber
    if (threatPct > 50) color = '#ff1530'; // Red

    // Foreground Active Arc
    let endAngle = Math.PI + (Math.PI * (threatPct / 100));
    ctx.beginPath();
    ctx.arc(cx, cy, r, Math.PI, endAngle);
    ctx.lineWidth = 12;
    ctx.strokeStyle = color;
    ctx.stroke();

    let pctText = document.getElementById('threatPct');
    if (pctText) {
        pctText.innerText = threatPct + '%';
        pctText.style.color = color;
    }

    let labelEl = document.getElementById('threatLabel');
    if (labelEl) {
        if (threatPct <= 20) {
            labelEl.innerText = "LOW";
            labelEl.className = "tl-badge tl-low";
        } else if (threatPct <= 50) {
            labelEl.innerText = "MED";
            labelEl.className = "tl-badge tl-med";
        } else {
            labelEl.innerText = "HIGH";
            labelEl.className = "tl-badge tl-high";
        }
    }
}

function drawActivityTimeline(logs) {
    let canvas = document.getElementById('activityChart');
    if (!canvas) return;
    
    if (canvas.width !== canvas.clientWidth) canvas.width = canvas.clientWidth;
    if (canvas.height !== canvas.clientHeight) canvas.height = canvas.clientHeight;

    let ctx = canvas.getContext('2d');
    let w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    if (!logs || logs.length === 0) return;

    let maxEvents = 20;
    let data = logs.slice(0, maxEvents).reverse();
    let stepX = w / Math.max(data.length - 1, 1);

    ctx.beginPath();
    
    data.forEach((log, i) => {
        let x = i * stepX;
        let score = Math.min(Math.max(log.score, 0), 100);
        let normalized = score / 100;
        let y = h - (normalized * (h - 20)) - 10; 

        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
    });

    ctx.lineWidth = 2;
    ctx.strokeStyle = '#00c8f0'; 
    ctx.stroke();

    ctx.lineTo(w, h);
    ctx.lineTo(0, h);
    let grad = ctx.createLinearGradient(0, 0, 0, h);
    grad.addColorStop(0, 'rgba(0, 200, 240, 0.4)');
    grad.addColorStop(1, 'rgba(0, 200, 240, 0)');
    ctx.fillStyle = grad;
    ctx.fill();
}

// ==========================================
// 🧭 TAB NAVIGATION LOGIC (Tumhari Request!)
// ==========================================
function setupTabs() {
    const tabs = document.querySelectorAll('.nav-tab');
    const logCard = document.querySelector('.log-card');
    const blCard = document.querySelector('.bl-card');

    tabs.forEach((tab, index) => {
        tab.addEventListener('click', () => {
            // 1. Sabhi tabs se 'active' color hatao
            tabs.forEach(t => t.classList.remove('active'));
            // 2. Jis tab pe click kiya usko 'active' (Cyan) karo
            tab.classList.add('active');

            // 3. Smooth Scrolling karo section ke hisaab se
            if (index === 0) {
                // Dashboard -> Upar le jao
                window.scrollTo({ top: 0, behavior: 'smooth' });
            } else if (index === 1 && logCard) {
                // Threat Log -> Log Table par le jao
                logCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
            } else if (index === 2 && blCard) {
                // Blacklist -> Blacklist box par le jao
                blCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        });
    });
}

// ==========================================
// 📡 DATA FETCHING LOGIC
// ==========================================

async function fetchLiveData() {
    try {
        let statsRes = await fetch(`${SERVER_URL}/stats`);
        if (!statsRes.ok) throw new Error("Server Error");
        let stats = await statsRes.json();
        
        failedAttempts = 0; 
        
        if (document.getElementById('sc-total')) document.getElementById('sc-total').innerText = stats.total || 0;
        if (document.getElementById('sc-safe')) document.getElementById('sc-safe').innerText = stats.safe || 0;
        if (document.getElementById('sc-blocked')) document.getElementById('sc-blocked').innerText = stats.blocked || 0;
        if (document.getElementById('sc-http')) document.getElementById('sc-http').innerText = stats.http_warnings || 0;
        if (document.getElementById('sc-bl')) document.getElementById('sc-bl').innerText = stats.blacklist_size || 0;
        
        let statusEl = document.getElementById('engineStatus');
        if (statusEl) {
            statusEl.className = "live-pill";
            statusEl.innerHTML = `<div class="live-dot"></div>Engine Live`;
        }

        let overlay = document.getElementById('offlineOverlay');
        if (overlay) overlay.classList.remove('show');

        drawThreatMeter(stats.total, stats.blocked);

        let logsRes = await fetch(`${SERVER_URL}/logs`);
        let logs = await logsRes.json();
        let tableBody = document.getElementById('logBody');
        
        if (tableBody) {
            tableBody.innerHTML = ""; 
            logs.forEach(log => {
                let pillClass = log.status === "SAFE" ? "pill-safe" : "pill-threat";
                if (log.status === "BLACKLISTED" || log.status === "BLOCKED") pillClass = "pill-blocked";
                
                tableBody.innerHTML += `
                    <tr>
                        <td class="td-time">${log.ts}</td>
                        <td class="td-domain">${log.domain}</td>
                        <td><span class="pill ${pillClass}">${log.status}</span></td>
                        <td class="td-score">${log.score}</td>
                        <td class="td-reason">${log.reason || "OK"}</td>
                    </tr>
                `;
            });
            let logCount = document.getElementById('logCount');
            if (logCount) logCount.innerText = `${logs.length} Events`;
        }

        drawActivityTimeline(logs);

        let blRes = await fetch(`${SERVER_URL}/blacklist`);
        let blData = await blRes.json();
        let blList = document.getElementById('blList');
        
        if (blList) {
            blList.innerHTML = "";
            if (blData.length === 0) {
                blList.innerHTML = `<div class="bl-empty">No blocked domains yet</div>`;
            } else {
                blData.forEach(domain => {
                    blList.innerHTML += `
                        <div class="bl-item">
                            <div class="bl-icon">🚫</div>
                            <div class="bl-domain">${domain}</div>
                        </div>
                    `;
                });
            }
            let blCount = document.getElementById('blCount');
            if (blCount) blCount.innerText = blData.length;
        }

    } catch (error) {
        failedAttempts++;
        if (failedAttempts >= 3) {
            let statusEl = document.getElementById('engineStatus');
            if (statusEl) {
                statusEl.className = "offline-pill";
                statusEl.innerHTML = `⚡ Offline`;
            }
            let overlay = document.getElementById('offlineOverlay');
            if (overlay) overlay.classList.add('show');
        }
    }
}

document.addEventListener("DOMContentLoaded", () => {
    fetchLiveData(); 
    setInterval(fetchLiveData, 2000); 
    setupTabs(); // <-- TABS LOGIC YAHAN ACTIVATE HO GAYA!

    setInterval(() => {
        let d = new Date();
        let el = document.getElementById('clockDisplay');
        if (el) el.innerText = d.toLocaleTimeString('en-US', { hour12: false });
    }, 1000);
});