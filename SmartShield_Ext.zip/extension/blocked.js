// SmartShield blocked.js — Sandbox Countdown + Double Verification
// Phase 1: 10s countdown  (button disabled + ring drains + ringNum ticks)
// Phase 2: Deep scan fires in parallel → phase label + badge updates
// Unlock: ONLY after BOTH countdown AND verify complete

(function () {
    "use strict";
  
    const SERVER = "http://localhost:8080";
  
    // ── Parse URL params ───────────────────────────────────────────
    const params  = new URLSearchParams(window.location.search);
    const domain  = params.get("domain")  || "unknown";
    const score   = parseFloat(params.get("score") || "0");
    const reason  = params.get("reason")  || "AI Heuristic";
    const origUrl = params.get("origUrl") || "";
  
    // ── Populate static fields ─────────────────────────────────────
    document.getElementById("domainDisplay").textContent = domain;
    document.getElementById("scoreDisplay").textContent  = score.toFixed(1);
    document.getElementById("reasonDisplay").textContent = reason;
  
    // Score bar fill animation
    const pct = Math.min((score / 20) * 100, 100);
    setTimeout(() => {
      document.getElementById("scoreBar").style.width = pct + "%";
    }, 400);
  
    // ── Live clock ─────────────────────────────────────────────────
    function tick() {
      const now = new Date();
      const tsEl = document.getElementById("ts");
      const dtEl = document.getElementById("dateDisplay");
      if (tsEl) tsEl.textContent = now.toLocaleTimeString("en-GB");
      if (dtEl) dtEl.textContent = now.toLocaleDateString("en-GB", {
        day: "2-digit", month: "short", year: "numeric"
      });
    }
    tick();
    setInterval(tick, 1000);
  
    // ── DOM refs ───────────────────────────────────────────────────
    const btnToggle    = document.getElementById("btnToggleConfirm");
    const btnReturn    = document.getElementById("btnReturnToSafety");
    const confirmPanel = document.getElementById("confirmPanel");
    const btnYes       = document.getElementById("btnProceedAnyway");
    const btnNo        = document.getElementById("btnCancelConfirm");
  
    // New elements in redesigned blocked.html
    const ringNum    = document.getElementById("ringNum");
    const ringFill   = document.getElementById("ringFill");
    const phaseLabel = document.getElementById("phaseLabel");
  
    // Detection cell: .gi .gv.warn (from original querySelector)
    const detectionCell = document.querySelector(".gi .gv.warn");
  
    // ── State ──────────────────────────────────────────────────────
    let phase         = "sandbox";
    let verifyDone    = false;
    let countdownDone = false;
    let verifyStatus  = null;   // "confirmed" | "lowered" | "failed"
  
    // ══════════════════════════════════════════════════════════════
    //  PHASE 1 — Sandbox countdown (10s)
    // ══════════════════════════════════════════════════════════════
    btnToggle.disabled = true;
    let remaining = 10;
  
    function renderCountdown(n) {
      btnToggle.innerHTML = `<span class="ss-spinner"></span>Sandboxing\u2026 ${n}s`;
      if (ringNum) ringNum.textContent = n;
    }
    renderCountdown(remaining);
  
    // Fire 2nd server check immediately (parallel to countdown)
    startDoubleVerification();
  
    const cdTimer = setInterval(() => {
      remaining -= 1;
      if (remaining > 0) {
        renderCountdown(remaining);
      } else {
        clearInterval(cdTimer);
        countdownDone = true;
        tryUnlock();
      }
    }, 1000);
  
    // ══════════════════════════════════════════════════════════════
    //  PHASE 2 — Double Verification (runs parallel to countdown)
    // ══════════════════════════════════════════════════════════════
    function startDoubleVerification() {
      if (detectionCell) {
        detectionCell.textContent = "Deep Scanning\u2026";
        detectionCell.classList.add("scanning-label");
        detectionCell.style.color = "";
      }
      if (phaseLabel) {
        phaseLabel.textContent  = "Deep Scanning\u2026";
        phaseLabel.className    = "phase-lbl scanning";
      }
  
      const checkUrl  = origUrl || ("http://" + domain);
      const ctrl      = new AbortController();
      const timeoutId = setTimeout(() => ctrl.abort(), 9000);
  
      fetch(SERVER + "/?url=" + encodeURIComponent(checkUrl), { signal: ctrl.signal })
        .then(r => r.json())
        .then(data => { clearTimeout(timeoutId); onVerifyResult(data, true); })
        .catch(()  => { clearTimeout(timeoutId); onVerifyResult(null, false); });
    }
  
    function onVerifyResult(data, success) {
      if (verifyDone) return;
      verifyDone = true;
  
      if (success && data) {
        // Refresh score + reason from live server response
        const freshScore = parseFloat(data.score) || score;
        document.getElementById("scoreDisplay").textContent = freshScore.toFixed(1);
        const freshPct = Math.min((freshScore / 20) * 100, 100);
        document.getElementById("scoreBar").style.width = freshPct + "%";
        if (data.reason) {
          document.getElementById("reasonDisplay").textContent = data.reason;
        }
  
        if (data.status === "BLOCKED") {
          verifyStatus = "confirmed";
          if (detectionCell) {
            detectionCell.classList.remove("scanning-label");
            detectionCell.textContent   = "CONFIRMED";
            detectionCell.style.color   = "var(--red)";
            detectionCell.style.fontWeight = "700";
          }
          if (phaseLabel) {
            phaseLabel.textContent = "Threat Confirmed";
            phaseLabel.className   = "phase-lbl done";
            phaseLabel.style.color = "var(--red, #ff1530)";
          }
          injectVerifyBadge("confirmed");
        } else {
          verifyStatus = "lowered";
          if (detectionCell) {
            detectionCell.classList.remove("scanning-label");
            detectionCell.textContent = "Risk Lowered";
            detectionCell.style.color = "var(--amber)";
          }
          if (phaseLabel) {
            phaseLabel.textContent = "Risk Lowered";
            phaseLabel.className   = "phase-lbl failed";
          }
          injectVerifyBadge("lowered");
        }
      } else {
        verifyStatus = "failed";
        if (detectionCell) {
          detectionCell.classList.remove("scanning-label");
          detectionCell.textContent = "Verify Failed";
          detectionCell.style.color = "var(--amber)";
        }
        if (phaseLabel) {
          phaseLabel.textContent = "Server Offline";
          phaseLabel.className   = "phase-lbl failed";
        }
        injectVerifyBadge("failed");
      }
  
      tryUnlock();
    }
  
    // Badge inserted before .score-bar element
    function injectVerifyBadge(type) {
      const old = document.getElementById("verifyBadge");
      if (old) old.remove();
  
      const cfg = {
        confirmed: { icon:"🔒", cls:"vb-confirmed", text:"Double Verification Complete — Threat Confirmed" },
        lowered:   { icon:"⚠️", cls:"vb-lowered",   text:"Re-check returned lower risk — proceed with caution" },
        failed:    { icon:"📡", cls:"vb-failed",    text:"Server offline during re-check — original block stands" }
      }[type];
  
      const badge = document.createElement("div");
      badge.id        = "verifyBadge";
      badge.className = "verify-badge " + cfg.cls;
      badge.innerHTML = `<span class="vb-icon">${cfg.icon}</span><span class="vb-text">${cfg.text}</span>`;
  
      const scoreBar = document.querySelector(".score-bar");
      if (scoreBar) scoreBar.parentNode.insertBefore(badge, scoreBar);
    }
  
    // ── Unlock: only when BOTH countdown AND verify are done ───────
    function tryUnlock() {
      if (!countdownDone || !verifyDone) return;
      if (phase === "ready") return;
      phase = "ready";
  
      // Update ring number and style
      if (ringNum) ringNum.textContent = "✓";
      if (ringFill) {
        ringFill.classList.remove("ring-ok", "ring-warn");
        ringFill.classList.add(verifyStatus === "confirmed" ? "ring-warn" : "ring-ok");
      }
  
      // Unlock button
      btnToggle.disabled = false;
      btnToggle.innerHTML = `<span class="warn-icon">\u26A0</span>\u00A0Proceed at your own risk`;
      btnToggle.classList.add("btn-continue-ready");
    }
  
    // ── Return to Safety ───────────────────────────────────────────
    btnReturn.addEventListener("click", () => {
      try {
        if (document.referrer && !document.referrer.includes("blocked.html")) {
          history.back();
        } else {
          chrome.tabs.update({ url: "chrome://newtab" });
        }
      } catch (e) { history.back(); }
    });
  
    // ── Toggle confirm panel ───────────────────────────────────────
    btnToggle.addEventListener("click", () => {
      if (btnToggle.disabled) return;
      confirmPanel.classList.toggle("show");
    });
  
    // ── Yes — bypass + navigate ────────────────────────────────────
    btnYes.addEventListener("click", () => {
      if (!origUrl) return;
      try {
        chrome.storage.local.get(["bypassed"], r => {
          const list = r.bypassed || [];
          if (!list.includes(domain)) list.push(domain);
          chrome.storage.local.set({ bypassed: list }, () => {
            chrome.tabs.update({ url: origUrl });
          });
        });
      } catch (e) { window.location.href = origUrl; }
    });
  
    // ── No — close panel ───────────────────────────────────────────
    btnNo.addEventListener("click", () => confirmPanel.classList.remove("show"));
  
  })();